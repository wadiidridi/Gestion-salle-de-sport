{
    'name': 'Cobra Tam  ',
    'version': '1.0',
    'category': 'Productivity',
    'summary': ' Cobra Team ',
    'description': """
    """,
    'depends': ['base', 'sale'],
    'data': [
        'security/ir.model.access.csv',
        'views/res_partner.xml',
        'views/menu_views.xml',
        'report/report.xml',

        'views/workout_category.xml',
        'Data/email_template.xml'


    ],
    'demo': [

    ],
    'installable': True,
    'auto_install': True,
    'license': 'LGPL-3',
}
