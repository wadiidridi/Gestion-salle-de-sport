from . import res_partner

from . import workout_category
