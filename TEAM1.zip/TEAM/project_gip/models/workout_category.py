from odoo import api, fields, models


class workout_category(models.Model):
    _name = 'workout.category'

    name = fields.Char('Name of discipline')
    coach = fields.Many2one('res.partner', domain=[('type_user', '=', 'coach')])



