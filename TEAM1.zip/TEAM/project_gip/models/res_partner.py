from odoo import models, fields, api


class ResPartner(models.Model):
    _inherit = 'res.partner'
    type_user = fields.Selection([('coach', 'Coach'), ('gerant', 'Gerant'), ('participant', 'Participant')],
                                 string="Type User", required=1)
    workout_style_ids = fields.Many2many('workout.category' )
    # number = fields.Char('number')
    #
    #
    # num_sub = fields.Integer(string='Number of participant', compute='comp_sub')
    Date_inscrit = fields.Date()



    def comp_sub(self):
        self.num_sub = len(self.number)

    #


    def send_mail(self):
        print("hiii")
        self.ensure_one()
        template_id = self.env.ref('project_gip.email_template_con')
        ctx = {
            'default_model': 'res.partner',
            'default_res_id': self.id,
            'default_use_template': bool(template_id),
            'default_template_id': template_id.id,
            'default_composition_mode': 'comment',
            'email_to': self.id,
        }
        return {
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'target': 'new',
            'context': ctx,
        }
